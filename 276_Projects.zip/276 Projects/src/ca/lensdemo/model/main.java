package ca.lensdemo.model;

import LensUI.ALensTextUI;
import ca.lensdemo.model.ALens;
import ca.lensdemo.model.ALensManager;

import java.util.ArrayList;
import java.util.List;

public class main {
    public static void main(String args[]) {

     ALensManager manager =new ALensManager();
     ALensTextUI ui=new ALensTextUI(manager);
     ui.show();




    }
}