package ca.lensdemo.model;

import ca.lensdemo.model.ALens;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
public class ALensManager implements Iterable<ALens> {
    private List<ALens> lenses = new ArrayList<>();

    @Override
    public Iterator<ALens> iterator() {
        return lenses.iterator();
    }

    public  void add (ALens lens) {lenses.add(lens);}





    public static void printLens(List<ALens> lenses){
        for(int i=0;i<lenses.size();i++ )
        {
            System.out.println("Lense" + i + lenses.get(i));
        }
    }

    public void getbyindex( int n){

        System.out.println("Specific Lens is" + lenses.get(n));

    }

    public ALens getobjbyindex(int n){
        return lenses.get(n);
    }

    public int getlistsize(){
        int count=0;
        for (ALens lenses55:lenses ){
            count++;
        }
    return count;
    }

}
