package ca.lensdemo.model;

public class ALens{
           private String make;
           private double maximumaperture;
           private double focallength;


           /*

public static Lens(String nmake,double aperture,double focallength) {
    this.make = nmake;
    this.maximumaperture = aperture;
    this.focallength = focallength;
}
*/

    public ALens(String make, double maximumaperture, double focallength) {
        this.make = make;
        this.maximumaperture = maximumaperture;
        this.focallength = focallength;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public double getMaximumaperture() {
        return maximumaperture;
    }

    public void setMaximumaperture(double maximumaperture) {
        this.maximumaperture = maximumaperture;
    }

    public double getFocallength() {
        return focallength;
    }

    public void setFocallength(double focallength) {
        this.focallength = focallength;
    }

    @Override
    public String toString() {
        return "ca.lensdemo.model.ALens{" +
                "make='" + make + '\'' +
                ", maximumaperture=" + maximumaperture +
                ", focallength=" + focallength +
                '}';
    }


}
