package ca.lensdemo.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ADepthofFieldCalculatorTest {

    @Test
    void getDistanceofobject(){
        ALens lense55=new ALens("Samsung",2.4,96);
        double dist=600;
        double apert=700;
        ADepthofFieldCalculator depthobj22=new ADepthofFieldCalculator(lense55,dist,apert);
        assertEquals(600, depthobj22.getDistanceofobject());

        //case 2
        ALens lense66=new ALens("Samsung",2.4,96);
        dist=700;
        apert=700;
        ADepthofFieldCalculator depthobj33=new ADepthofFieldCalculator(lense66,dist,apert);
        assertEquals(700, depthobj33.getDistanceofobject());
        //case 3
        ALens lense77=new ALens("Nikkon",2.4,96);
        dist=800;
        apert=700;
        ADepthofFieldCalculator depthobj44=new ADepthofFieldCalculator(lense66,dist,apert);
        assertEquals(800, depthobj44.getDistanceofobject());


    }



    @Test
    void gethyperfocaldistance() {
        ALens lens = new ALens("NIKKON", 1.8, 50);

        //Case 1:
        double dist34 = 1100, aperture34 = 1.8;
        ADepthofFieldCalculator depthobj111 = new ADepthofFieldCalculator(lens, dist34, aperture34);
        double expected = 47890.0 / 1000;
        assertEquals(expected, depthobj111.gethyperfocaldistance() / 1000, 0.005);

        //Case 2:
        dist34 = 1000;
        aperture34 = 8;
        ADepthofFieldCalculator depthobj222 = new ADepthofFieldCalculator(lens, dist34, aperture34);
        expected = 10780.0 / 1000;
        assertEquals(expected, depthobj222.gethyperfocaldistance() / 1000, 0.005);

        //Case 3:
        dist34 = 15000;
        aperture34 = 11;
        ADepthofFieldCalculator dof3 = new ADepthofFieldCalculator(lens, dist34, aperture34);
        expected = 7840.0 / 1000;
        assertEquals(expected, dof3.gethyperfocaldistance() / 1000, 0.005);
    }

    @Test
    void getnearfocalpoint() {
        ALens lens = new ALens("Samsung", 1.8, 50);

        //Case 1:
        double dist555 = 1100, aperture566 = 1.8;
        ADepthofFieldCalculator dof1 = new ADepthofFieldCalculator(lens, dist555, aperture566);
        double expected = 1.08;
        assertEquals(expected, dof1.getnearfocalpoint() / 1000, 0.005);

        //Case 2:
        dist555 = 1000;
        aperture566 = 8;
        ADepthofFieldCalculator dof2 = new ADepthofFieldCalculator(lens, dist555, aperture566);
        expected = 0.92;
        assertEquals(expected, dof2.getnearfocalpoint() / 1000, 0.005);

        //Case 3:
        dist555 = 15000;
        aperture566 = 11;
        ADepthofFieldCalculator dof3 = new ADepthofFieldCalculator(lens, dist555, aperture566);
        expected = 5.16;
        assertEquals(expected, dof3.getnearfocalpoint() / 1000, 0.005);
    }

    @Test
    void getfarfocalpoint() {
        ALens lens = new ALens("Canon", 1.8, 50);

        //Case 1:
        double dist999 = 1100, aperture888 = 1.8;
        ADepthofFieldCalculator dof1 = new ADepthofFieldCalculator(lens, dist999, aperture888);
        double expected = 1.12;
        assertEquals(expected, dof1.getfarfocalpoint() / 1000, 0.005);

        //Case 2:
        dist999 = 1000;
        aperture888 = 8;
        ADepthofFieldCalculator dof2 = new ADepthofFieldCalculator(lens, dist999, aperture888);
        expected = 1.10;
        assertEquals(expected, dof2.getfarfocalpoint() / 1000, 0.005);

        //Case 3:
        dist999 = 15000;
        aperture888 = 11;
        ADepthofFieldCalculator dof3 = new ADepthofFieldCalculator(lens, dist999, aperture888);
        expected = Double.POSITIVE_INFINITY;
        assertEquals(expected, dof3.getfarfocalpoint() / 1000, 0.005);
    }

    @Test
    void getLens(){
        ALens lens2=new ALens("Cannon",1.8,50);
        double distOfObj = 1100, fVal = 1.8;
        ADepthofFieldCalculator dof4=new ADepthofFieldCalculator(lens2,distOfObj,fVal);
        assertEquals(lens2,dof4.getLens());
        //case 2
        ALens lens22=new ALens("Toshiba",1.7,45);

        ADepthofFieldCalculator dof5=new ADepthofFieldCalculator(lens22,distOfObj,fVal);
        assertEquals(lens22,dof5.getLens());
        //case 3
        ALens lens33= new ALens("Samsung",1.4,70);
        ADepthofFieldCalculator dof7=new ADepthofFieldCalculator(lens33,distOfObj,fVal);
        assertEquals(lens33,dof7.getLens());

    }

    @Test
    void setLens(){
        ALens lense11=new ALens("Nikkon",2.3,90);
        ALens lense22=new ALens("Samsung",2.6,67);
        double distanceofobject=500;
        double currentapperture=300;
        ADepthofFieldCalculator depthobject1=new ADepthofFieldCalculator(lense11,distanceofobject,currentapperture);
        depthobject1.setLens(lense22);
        assertEquals(lense22,depthobject1.getLens());

        //case 2
        ALens lense33=new ALens("Alpha",2.4,96);
        ALens lense44=new ALens("Samsung",2.9,76);
         distanceofobject=500;
         currentapperture=300;
        ADepthofFieldCalculator depthobject2=new ADepthofFieldCalculator(lense33,distanceofobject,currentapperture);
        depthobject1.setLens(lense44);
        assertEquals(lense33,depthobject2.getLens());

    }



    @Test
    void setDistanceofobject(){
        ALens lense89=new ALens("Samsung",2.4,96);
        double dist1=600;
        double dist2=200;
        double apert1=700;
        ADepthofFieldCalculator depthobj23=new ADepthofFieldCalculator(lense89,dist1,apert1);
        depthobj23.setDistanceofobject(dist2);
        assertEquals(200, depthobj23.getDistanceofobject());
        //case 2
        ALens lense98=new ALens("Nikkon",2.4,96);
         dist1=400;
         dist2=300;
         apert1=700;
        ADepthofFieldCalculator depthobj32=new ADepthofFieldCalculator(lense89,dist1,apert1);
        depthobj23.setDistanceofobject(dist2);
        assertEquals(300, depthobj23.getDistanceofobject());
        //case 3
        ALens lense908=new ALens("Nikkon",2.4,96);
        dist1=100;
        dist2=200;
        apert1=700;
        ADepthofFieldCalculator depthobj302=new ADepthofFieldCalculator(lense89,dist1,apert1);
        depthobj302.setDistanceofobject(dist2);
        assertEquals(200, depthobj302.getDistanceofobject());

    }

    @Test
    void getCurrentaperture(){
        ALens lll=new ALens("SONY",6.7,58);
        double distancefromobject=200;
        double aperturenotmax=2.0;
        ADepthofFieldCalculator depthobj44= new ADepthofFieldCalculator(lll,distancefromobject,aperturenotmax);
        assertEquals(2.0,depthobj44.getCurrentaperture());
        //case 2
        ALens ll=new ALens("OLYMPUS",7.6,85);
         distancefromobject=300;
         aperturenotmax=3.0;
        ADepthofFieldCalculator depthobj445= new ADepthofFieldCalculator(lll,distancefromobject,aperturenotmax);
        assertEquals(3.0,depthobj445.getCurrentaperture());
        //case 3
        ALens l=new ALens("FUJIFILM",2.7,508);
         distancefromobject=400;
         aperturenotmax=1.0;
        ADepthofFieldCalculator depthobj454= new ADepthofFieldCalculator(lll,distancefromobject,aperturenotmax);
        assertEquals(1.0,depthobj454.getCurrentaperture());

    }

    @Test
    void setCurrentaperture(){
        ALens lastlens= new ALens ("NIKKON",3.0,500);
        ADepthofFieldCalculator lastdepth=new ADepthofFieldCalculator(lastlens,200,3.4);
        double newaperture=2.0;
        lastdepth.setCurrentaperture(newaperture);
        assertEquals(newaperture,lastdepth.getCurrentaperture(),0.1);
        //case 2
        newaperture=3.0;
        lastdepth.setCurrentaperture(newaperture);
        assertEquals(newaperture,lastdepth.getCurrentaperture(),0.01);
        //case 3
        newaperture=4.0;
        lastdepth.setCurrentaperture(newaperture);
        assertEquals(newaperture,lastdepth.getCurrentaperture());

    }











}
