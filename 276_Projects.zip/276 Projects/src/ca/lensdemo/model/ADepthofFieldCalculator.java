package ca.lensdemo.model;

public class ADepthofFieldCalculator {


    private ALens lens;
    private double distanceofobject;
    private double currentaperture;
    public static final double circleofconfusion= 0.029;

    public ADepthofFieldCalculator(ALens lens, double distanceofobject, double currentaperture) {
        this.lens = lens;
        this.distanceofobject = distanceofobject;
        this.currentaperture = currentaperture;


    }

    public ALens getLens() {
        return lens;
    }

    public void setLens(ALens lens) {
        this.lens = lens;
    }

    public double getDistanceofobject() {
        return distanceofobject;
    }

    public void setDistanceofobject(double distanceofobject) {
        this.distanceofobject = distanceofobject;
    }

    public double getCurrentaperture() {
        return currentaperture;
    }

    public void setCurrentaperture(double currentaperture) {
        this.currentaperture = currentaperture;
    }

    public static double getCircleofconfusion() {
        return circleofconfusion;
    }

    public double gethyperfocaldistance(){
        return (Math.pow(this.lens.getFocallength(), 2) /
                (this.currentaperture*circleofconfusion));

    }

    public double getnearfocalpoint(){
        return ((gethyperfocaldistance()*getDistanceofobject()) /
                (gethyperfocaldistance() + (getDistanceofobject()-(getLens().getFocallength()))));
    }

    public double getfarfocalpoint(){
        double farfocalpoint= ((gethyperfocaldistance()*getDistanceofobject()) /
                (gethyperfocaldistance() - (getDistanceofobject()-(getLens().getFocallength()))));
        if(getDistanceofobject()>gethyperfocaldistance()){
            farfocalpoint=Double.POSITIVE_INFINITY;
        }
        return farfocalpoint;
    }
    public double getdepthoffield(){
        double depthoffield;
        depthoffield=(getfarfocalpoint()-getnearfocalpoint());
        return depthoffield;
    }


}




