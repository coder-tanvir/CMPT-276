package LensUI;

import ca.lensdemo.model.ADepthofFieldCalculator;
import ca.lensdemo.model.ALens;
import ca.lensdemo.model.ALensManager;
import java.text.DecimalFormat;


import java.util.Scanner;

public class ALensTextUI {
    private ALensManager manager;

    public ALensTextUI(ALensManager manager) {
        this.manager = manager;
        manager.add(new ALens("Canon", 1.2, 50));
        manager.add(new ALens("nikkon", 2.3, 90));
        manager.add(new ALens("Samsung", 4, 100));
        manager.add(new ALens("Toshiba", 5.6, 200));
    }
    private String formatM(double distanceInM) {
        DecimalFormat df = new DecimalFormat("0.00");
        return df.format(distanceInM);
    }

    public void show(){
        boolean isdone=false;
        while(!isdone){
            System.out.println("Enter option 1=Known list || 2=input an index number, aperture and distance from object");
            Scanner in=new Scanner(System.in);
            int choice=in.nextInt();

            switch(choice){
                case 1:
                    System.out.println("Here is a list of the Known lenses");
                    for (ALens lense12 : manager) {
                        System.out.println("Lens" + lense12);
                    }
                    break;

                case 2:
                    System.out.println("Enter an index number");
                    int indexnumber=in.nextInt();
                    if(indexnumber==-1){
                       System.out.println("System Exiting");
                       isdone=true;
                    }
                    else if (indexnumber >= 0 && indexnumber <= manager.getlistsize()) {


                        manager.getbyindex(indexnumber);
                        System.out.println("Please enter an aperture number less than maximum aperture");
                        double inputaperture = in.nextDouble();
                        ALens madelense = manager.getobjbyindex(indexnumber);
                        if (madelense.getMaximumaperture() > inputaperture && inputaperture!=0) {
                            System.out.println("please enter the distance from object greater than 0 ");
                            double inputdistance = in.nextDouble();
                            double distancemultiplied = inputdistance * 1000;
                            ADepthofFieldCalculator newdepthobject = new ADepthofFieldCalculator(madelense, distancemultiplied, inputaperture);
                            String nearfocal = formatM(newdepthobject.getnearfocalpoint() / 1000);
                            String farfocal = formatM(newdepthobject.getfarfocalpoint() / 1000);
                            String hyperfocal = formatM(newdepthobject.gethyperfocaldistance() / 1000);
                            String depthoffield = formatM(newdepthobject.getdepthoffield() / 1000);
                            System.out.println("In focus: " + nearfocal + "m to " + farfocal + "m [DOF = " + depthoffield + "m]");
                            System.out.println("Hyperfocal point: " + hyperfocal + "m");



                        } else {
                            System.out.println("Sorry crossed the maximum aperture.Sytem exiting");
                            isdone = true;
                        }




                    }else{
                        System.out.println("EXIT");
                        isdone=true;

                    }








            }
        }




    }
}
